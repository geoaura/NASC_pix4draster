#QGIS Plugin version 5.0.0
###########################################

import time
from .module.band_composite import *
from .module.vegetation_index import *

###########################################
# Band composite
def composite_process_directory(directory_path, sensor):
  print ("\n")
  band_composite(directory_path, sensor)
  
def vi_process_directory(directory_path, sensor):
  cal_vi(directory_path, sensor)
  print ("\n")  