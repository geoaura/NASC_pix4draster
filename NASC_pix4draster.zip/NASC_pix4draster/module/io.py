from osgeo import gdal
import glob
import numpy as np

def geotiff_input(inputpath):
  nt = len(glob.glob(inputpath))
  if nt != 0:
    ds = gdal.Open(glob.glob(inputpath)[0])
    ycor, xcor, zcor = ds.RasterYSize, ds.RasterXSize, ds.RasterCount
    GeoTransform=ds.GetGeoTransform()
    Projection =ds.GetProjection()  
    Band=np.dstack([ds.GetRasterBand(k).ReadAsArray() for k in range(1,zcor+1,1)])
    ds=None
    
    return Band, xcor, ycor, zcor, GeoTransform, Projection
  else:
    print ("Check data")

def geotiff_output(outputpath, xcor, ycor, zcor, GeoTransform, Projection, var):
  driver1= gdal.GetDriverByName("GTiff")
  VAR_GDAL=driver1.Create(outputpath, xcor, ycor, 1, gdal.GDT_Float32, options=['COMPRESS=LZW','PREDICTOR=2','ZLEVEL=9']) 
  VAR_GDAL.SetGeoTransform(GeoTransform)
  VAR_GDAL.SetProjection(Projection)        
  VAR_GDAL.GetRasterBand(1).WriteArray(var)
  VAR_GDAL.GetRasterBand(1).SetNoDataValue(-10000)
  VAR_GDAL.FlushCache()
  del VAR_GDAL