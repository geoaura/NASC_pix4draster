#2023.08.22. made by Jae-Hyun Ryu

import os
import sys
import glob
import shutil
from osgeo import gdal
from time import sleep

#######################################
def drone_p4mc(path, outpath, sensor, file_len, flag):
  output_name=os.path.basename(glob.glob(path+"//*.tif")[0])[:file_len]
  if flag==1:
    if len(glob.glob(path+"//*.tif")) != 5: 
      print ("Please check "+sensor+" and number of data")
      quit()

    for name in ['prj', 'tfw', 'tif']:
      b475=glob.glob(path+"//*blue."+name)
      b560=glob.glob(path+"//*green."+name)
      b668=glob.glob(path+"//*red."+name)
      b717=glob.glob(path+"//*red*edge."+name)
      b842=glob.glob(path+"//*nir."+name)
    
      if len(b475)>0: b475fn=os.path.basename(b475[0])[:-3]
      if len(b560)>0: b560fn=os.path.basename(b560[0])[:-3]
      if len(b668)>0: b668fn=os.path.basename(b668[0])[:-3]
      if len(b717)>0: b717fn=os.path.basename(b717[0])[:-3]
      if len(b842)>0: b842fn=os.path.basename(b842[0])[:-3]

      if len(b475)>0: shutil.copy2( path+'//'+b475fn+name, outpath+'//'+b475fn[:file_len]+'_B01_475nm.'+name )
      if len(b560)>0: shutil.copy2( path+'//'+b560fn+name, outpath+'//'+b560fn[:file_len]+'_B02_560nm.'+name )
      if len(b668)>0: shutil.copy2( path+'//'+b668fn+name, outpath+'//'+b668fn[:file_len]+'_B03_668nm.'+name )
      if len(b717)>0: shutil.copy2( path+'//'+b717fn+name, outpath+'//'+b717fn[:file_len]+'_B04_717nm.'+name )
      if len(b842)>0: shutil.copy2( path+'//'+b842fn+name, outpath+'//'+b842fn[:file_len]+'_B05_842nm.'+name )
      
  tifs=glob.glob(outpath+"//*_B*.tif")
  tifs.sort()    
  if len(tifs)==5:
    path1 =outpath+"//"+output_name+".vrt"    
    path2=outpath+"//"+output_name+".tif"
    if flag==1:
      [os.remove(f) for f in glob.glob(outpath+"//"+output_name+".vrt")]
      [os.remove(f) for f in glob.glob(outpath+"//"+output_name+".tif")]      
      if not os.path.exists(outpath+"//"+output_name+".vrt") :
        print ("    03-1. make vrt")   
        output = gdal.BuildVRT(path1, tifs, separate=True)
        sleep(3)
      else:
        print ("    03-1. vrt file exist")

    if flag==2:
      if not os.path.exists(outpath+"//"+output_name+".tif") :
        sleep(3)
        print ("    03-2. convert vrt to tif")        
        gdal.Translate(path2, path1, format='GTiff', creationOptions=["COMPRESS=LZW"])
        
        sleep(3)
        [os.remove(f) for f in glob.glob(outpath+"\\*.vrt")]
        [os.remove(f) for f in glob.glob(outpath+"\\*nm.prj")]
        [os.remove(f) for f in glob.glob(outpath+"\\*nm.tfw")]
        [os.remove(f) for f in glob.glob(outpath+"\\*nm.tif")]
        
        return path2, tifs
      else:
        print ("    03-2. tif file exist")    
    
  else:
    print ("    03. Please check "+sensor+" files")
    quit()
