from osgeo import gdal
from .util import *
from .io import *
import os
import numpy as np
import glob

def vi_filter(vi):
  vi[vi<-1]=-1
  vi[vi> 1]=1
  vi[vi==0]=-10000
  return vi

def cal_vi (path, sensor):

  [os.remove(f) for f in glob.glob(path+"/*_index_*.tif")]

  flist =glob.glob(path+'/*.tif')[0]
  #sensor=flist[-8:-8+4]
  
  if   sensor == 'rededge-mx'             : sensor_name='remx'
  elif sensor == 'rededge-mx dual'        : sensor_name='dual'
  elif sensor == 'rededge-P'              : sensor_name='redp'
  elif sensor == 'phantom 4 multispectral': sensor_name='p4mc'
  elif sensor == 'mavic 3 multispectral'  : sensor_name='m3mc'
  else                                    : sensor_name='none'

  Band, xcor, ycor, zcor, GeoTransform, Projection = geotiff_input(flist)
  if sensor_name=='dual':   #band10
    R560=np.array(Band[:,:,3])
    R668=np.array(Band[:,:,5])
    R717=np.array(Band[:,:,7])
    R842=np.array(Band[:,:,9])
  elif sensor_name=='m3mc': #band4
    R560=np.array(Band[:,:,0])
    R668=np.array(Band[:,:,1])
    R717=np.array(Band[:,:,2])
    R842=np.array(Band[:,:,3])    
  elif sensor_name=='p4mc': #band4
    R560=np.array(Band[:,:,0])
    R668=np.array(Band[:,:,1])
    R717=np.array(Band[:,:,2])
    R842=np.array(Band[:,:,3])
  elif sensor_name=='redp': #band5
    R560=np.array(Band[:,:,1])
    R668=np.array(Band[:,:,2])
    R717=np.array(Band[:,:,3])
    R842=np.array(Band[:,:,4])
  elif sensor_name=='remx': #band5
    R560=np.array(Band[:,:,1])
    R668=np.array(Band[:,:,2])
    R717=np.array(Band[:,:,3])
    R842=np.array(Band[:,:,4])
    
  NDVI =((R842-R668)/(R842+R668)).astype(np.float32)
  GNDVI=((R842-R560)/(R842+R560)).astype(np.float32)
  NDRE =((R842-R717)/(R842+R717)).astype(np.float32)
  
  del R560
  del R668
  del R717
  del R842
  del Band  
  
  NDVI =vi_filter(NDVI)
  GNDVI=vi_filter(GNDVI)
  NDRE =vi_filter(NDRE)
  print ('05. vegetation index list:')
  for var, name in list(zip([NDVI,GNDVI, NDRE], ['NDVI','GNDVI','NDRE'])):
    outputpath=path+'/'+os.path.basename(flist)[:-4]+'_index_'+name+'.tif'
    print('    '+os.path.basename(outputpath))
    geotiff_output(outputpath, xcor, ycor, zcor, GeoTransform, Projection, var)
    
  del NDVI
  del GNDVI
  del NDRE