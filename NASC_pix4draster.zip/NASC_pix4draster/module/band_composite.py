#2023.08.22. made by Jae-Hyun Ryu
#2023.08.23. add filename length 20 modified by Jae-Hyun Ryu             

import time
import glob
from time import sleep
from .util import *
from .drone_remx import *
from .drone_redp import *
from .drone_dual import *
from .drone_p4mc import *
from .drone_m3mc import *

def band_composite(path, sensor):
  now =time.localtime()
  now2="%04d%02d%02d_%02d%02d%02d" % (now.tm_year, now.tm_mon, now.tm_mday, now.tm_hour, now.tm_min, now.tm_sec)

  inputpath =path+'/4_index/reflectance' 
  outputpath=path+'/1_initial/report'
  file_len=len(path.split('/')[-1])
  
  if   sensor == 'rededge-mx'             : sensor_name='remx'
  elif sensor == 'rededge-mx dual'        : sensor_name='redu'
  elif sensor == 'rededge-P'              : sensor_name='redp'
  elif sensor == 'phantom 4 multispectral': sensor_name='p4mc'
  elif sensor == 'mavic 3 multispectral'  : sensor_name='m3mc'
  else                                    : sensor_name='none'
  
  if sensor_name == 'remx' or sensor_name == 'redu' or sensor_name == 'redp' or sensor_name == 'p4mc' or sensor_name == 'm3mc':
    print ("01. input path:", inputpath)
    print ("02. sensor:", sensor)
    print ("03. output path:", outputpath)

    if sensor_name=='remx':
      flag=1
      drone_remx(inputpath, outputpath, sensor_name, file_len, flag)
      flag=2
      opath_fname, tifs = drone_remx(       inputpath, outputpath, sensor_name, file_len, flag)
      log_flag=1
    elif sensor_name=='redu':
      flag=1
      drone_dual(inputpath, outputpath, sensor_name, file_len, flag)
      flag=2
      opath_fname, tifs = drone_dual(       inputpath, outputpath, sensor_name, file_len, flag)    
      log_flag=1
    elif sensor_name=='redp':
      flag=1
      drone_redp(inputpath, outputpath, sensor_name, file_len, flag)
      flag=2
      opath_fname, tifs = drone_redp(       inputpath, outputpath, sensor_name, file_len, flag)    
      log_flag=1
    elif sensor_name=='p4mc':
      flag=1
      drone_p4mc(inputpath, outputpath, sensor_name, file_len, flag)
      flag=2
      opath_fname, tifs = drone_p4mc(       inputpath, outputpath, sensor_name, file_len, flag)    
      log_flag=1   
    elif sensor_name=='m3mc':
      flag=1
      drone_m3mc(inputpath, outputpath, sensor_name, file_len, flag)
      flag=2
      opath_fname, tifs = drone_m3mc(       inputpath, outputpath, sensor_name, file_len, flag)    
      log_flag=1       
    else:
      tifs=[]
      log_flag=2      
      
    print ('04. Band list:')
    for filepath in tifs:
      filename = os.path.basename(filepath)
      print('    '+filename)  

  else:         
    sensor  ='none'
    tifs    =[]
    log_flag=3
    print ('Please check drone file name')
    print ('exit')  