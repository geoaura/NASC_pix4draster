# -*- coding: utf-8 -*-
# 센서별 밴드 구성 정의 (drone_remx/redu/redp/p4mc/m3mc 모듈 통합)
# bands: (파일명 glob 패턴, 중심파장 nm) — 밴드 순서(B01, B02, ...)대로 나열
# n_files: 입력 tif 개수 허용 범위 (min, max)

SENSORS = {
    'rededge-mx': {
        'code': 'remx',
        'n_files': (5, 5),
        'bands': [
            ('blue',      475),
            ('green',     560),
            ('red',       668),
            ('red*edge',  717),
            ('nir',       842),
        ],
    },
    'rededge-mx dual': {
        'code': 'redu',
        'n_files': (10, 10),
        'bands': [
            ('444',       444),
            ('blue',      475),
            ('531',       531),
            ('green',     560),
            ('650',       650),
            ('red',       668),
            ('705',       705),
            ('red*edge',  717),
            ('740',       740),
            ('nir',       842),
        ],
    },
    'rededge-P': {
        'code': 'redp',
        'n_files': (5, 6),
        'bands': [
            ('blue',      475),
            ('green',     560),
            ('red',       668),
            ('red*edge',  717),
            ('nir',       842),
        ],
    },
    'phantom 4 multispectral': {
        'code': 'p4mc',
        'n_files': (5, 5),
        'bands': [
            ('blue',      475),
            ('green',     560),
            ('red',       668),
            ('red*edge',  717),
            ('nir',       842),
        ],
    },
    'mavic 3 multispectral': {
        'code': 'm3mc',
        'n_files': (4, 4),
        'bands': [
            ('green',     560),
            ('red',       668),
            ('red*edge',  717),
            ('nir',       842),
        ],
    },
    # RGB 카메라: Pix4D 정사모자이크(RGBA 단일파일)에서 Alpha 밴드 제외 후 RGB 저장
    # 입력 경로가 다중분광(4_index/reflectance)과 다름: 3_dsm_ortho/2_mosaic
    'rgb camera': {
        'code': 'rgbc',
        'type': 'rgb',
        'input_subdir': '3_dsm_ortho/2_mosaic',
        'vi': False,
    },
}

# 식생지수 계산에 사용하는 파장 (nm)
VI_WAVELENGTHS = (560, 668, 717, 842)

# 다중분광 공통 기본값
MS_INPUT_SUBDIR = '4_index/reflectance'

# 공통 상수
SCALE_FACTOR = 10000
NODATA = -20000
