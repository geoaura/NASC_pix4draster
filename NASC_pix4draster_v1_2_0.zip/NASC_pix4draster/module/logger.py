# -*- coding: utf-8 -*-
"""처리 로그 및 오류 정의.

모듈의 print() 출력을 GUI 창으로 전달하기 위한 sink 구조를 제공한다.
sink가 설정되지 않으면 표준 출력(print)으로 동작한다.
"""

import os
import time


class ProcessError(Exception):
    """사용자에게 원인과 조치를 안내할 수 있는 처리 오류.

    message: 무엇이 잘못되었는지
    hint:    어떻게 해결하는지 (선택)
    """

    def __init__(self, message, hint=None):
        super(ProcessError, self).__init__(message)
        self.message = message
        self.hint = hint


class Log(object):

    def __init__(self):
        self._sink = None
        self._t_start = None
        self._t_step = None
        self.warn_count = 0
        self.error_count = 0
        self.lines = []

    # --- sink 연결 ---
    def set_sink(self, fn):
        """GUI 등 외부 출력 함수 연결. None이면 print 사용."""
        self._sink = fn

    def reset(self):
        self.warn_count = 0
        self.error_count = 0
        self.lines = []
        self._t_start = time.time()
        self._t_step = self._t_start

    # --- 내부 출력 ---
    def _emit(self, text):
        self.lines.append(text)
        if self._sink is not None:
            try:
                self._sink(text + "\n")
                return
            except Exception:
                pass
        print(text)

    def _stamp(self):
        return time.strftime("%H:%M:%S")

    # --- 출력 형식 ---
    def blank(self):
        self._emit("")

    def title(self, text):
        self._emit("=" * 60)
        self._emit(text)
        self._emit("=" * 60)

    def section(self, text):
        self._emit("")
        self._emit("[%s] %s" % (self._stamp(), text))
        self._emit("-" * 60)

    def step(self, text):
        self._emit("  > %s" % text)

    def detail(self, text):
        self._emit("      %s" % text)

    def info(self, text):
        self._emit("  - %s" % text)

    def ok(self, text):
        self._emit("  [OK] %s" % text)

    def warn(self, text):
        self.warn_count += 1
        self._emit("  [주의] %s" % text)

    def error(self, text):
        self.error_count += 1
        self._emit("  [오류] %s" % text)

    def hint(self, text):
        self._emit("         -> 조치: %s" % text)

    # --- 시간 측정 ---
    def lap(self, label):
        now = time.time()
        if self._t_step is None:
            self._t_step = now
        self._emit("  [OK] %s (%.1f초)" % (label, now - self._t_step))
        self._t_step = now

    def total_elapsed(self):
        if self._t_start is None:
            return 0.0
        return time.time() - self._t_start

    # --- 로그 파일 저장 ---
    def save_to_file(self, outpath, project_name=None, extra_lines=None):
        """처리 과정을 텍스트 파일로 저장. 성공 시 파일 경로, 실패 시 None."""
        if not outpath or not os.path.isdir(outpath):
            return None

        stamp = time.strftime("%Y%m%d_%H%M%S")
        prefix = (project_name + '_') if project_name else ''
        filepath = os.path.join(outpath, '%slog_%s.txt' % (prefix, stamp))

        body = list(self.lines)
        if extra_lines:
            body = list(extra_lines) + body

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write('\n'.join(body))
                f.write('\n')
        except Exception:
            return None
        return filepath


# 모듈 전역 로거
log = Log()


def human_size(num_bytes):
    """바이트를 읽기 쉬운 단위로 변환."""
    for unit in ('B', 'KB', 'MB', 'GB'):
        if num_bytes < 1024.0 or unit == 'GB':
            return "%.1f %s" % (num_bytes, unit)
        num_bytes /= 1024.0
