# -*- coding: utf-8 -*-
# 2023.08.22. made by Jae-Hyun Ryu
# v1.2.0  센서 설정 기반 통합 처리, rgb camera 지원, 입력 검증·오류 진단 강화

import os
import glob
import shutil
import numpy as np
from osgeo import gdal

from .sensors import SENSORS, SCALE_FACTOR, NODATA, MS_INPUT_SUBDIR
from .logger import log, ProcessError, human_size
from .io import (clean_report_folder, raster_info, check_grid_consistency,
                 band_statistics, GdalErrorCollector, free_space, _write_fail_hint,
                 wait_for_rasters)

# Pix4D 산출물 파일명에서 프로젝트명 앞의 접미어 구분자
_PIX4D_MARKERS = (
    '_transparent_reflectance_',
    '_transparent_mosaic_',
    '_reflectance_',
    '_mosaic_',
)


def _project_name(filepath, folder_path):
    """Pix4D 산출물 파일명에서 프로젝트명 추출."""
    stem = os.path.splitext(os.path.basename(filepath))[0]
    for marker in _PIX4D_MARKERS:
        if marker in stem:
            return stem.split(marker)[0]
    return os.path.basename(os.path.normpath(folder_path.replace('\\', '/')))


# ------------------------------------------------------------------ 사전 검증
def validate_project_folder(path, cfg, sensor):
    """프로젝트 폴더와 입력 자료를 검사하고 입력 경로를 반환."""
    if not path:
        raise ProcessError("폴더가 선택되지 않았습니다.", "[Select Folder]로 Pix4D 프로젝트 폴더를 선택하세요.")
    if not os.path.isdir(path):
        raise ProcessError("폴더를 찾을 수 없습니다: %s" % path,
                           "이동·삭제되었거나 네트워크 드라이브 연결이 끊겼는지 확인하세요.")

    subdir = cfg.get('input_subdir', MS_INPUT_SUBDIR)
    inputpath = os.path.join(path, subdir)

    if not os.path.isdir(inputpath):
        other = MS_INPUT_SUBDIR if cfg.get('type') == 'rgb' else SENSORS['rgb camera']['input_subdir']
        extra = ""
        if os.path.isdir(os.path.join(path, other)):
            kind = "다중분광" if cfg.get('type') == 'rgb' else "RGB"
            extra = (" 다만 '%s' 폴더는 존재합니다. %s 자료로 보이니 센서 선택을 확인하세요."
                     % (other, kind))
        raise ProcessError(
            "입력 폴더가 없습니다: %s" % inputpath,
            "Pix4D 프로젝트의 최상위 폴더를 선택했는지 확인하세요."
            " (선택한 폴더 안에 '%s' 경로가 있어야 합니다.)%s" % (subdir, extra))

    tifs = sorted(glob.glob(os.path.join(inputpath, '*.tif')))
    if not tifs:
        raise ProcessError(
            "입력 폴더에 GeoTIFF가 없습니다: %s" % inputpath,
            "Pix4D에서 해당 산출물이 생성되었는지 확인하세요."
            " (다중분광은 반사도 지도, RGB는 정사모자이크 생성 옵션)")

    return inputpath, tifs


def _suggest_sensor(n_files):
    """파일 개수에 맞는 센서 후보 제시."""
    cands = []
    for name, c in SENSORS.items():
        if c.get('type') == 'rgb':
            continue
        lo, hi = c['n_files']
        if lo <= n_files <= hi:
            cands.append(name)
    return cands


def _check_file_count(tifs, cfg, sensor):
    n = len(tifs)
    lo, hi = cfg['n_files']
    if lo <= n <= hi:
        return
    expect = "%d개" % lo if lo == hi else "%d~%d개" % (lo, hi)
    cands = _suggest_sensor(n)
    hint = "Pix4D 반사도 산출 설정에서 밴드가 모두 생성되었는지 확인하세요."
    if cands:
        hint = "파일 개수로 보아 '%s' 센서가 맞을 수 있습니다. 센서 선택을 확인하세요." % ', '.join(cands)
    raise ProcessError(
        "'%s'는 반사도 영상 %s가 필요하나 %d개를 찾았습니다." % (sensor, expect, n),
        hint)


def _match_bands(inputpath, bands, sensor):
    """센서 밴드 정의에 해당하는 파일을 찾고 누락/중복을 검사."""
    matched, missing, ambiguous = [], [], []
    for band_no, (pattern, wavelength) in enumerate(bands, start=1):
        hits = sorted(glob.glob(os.path.join(inputpath, '*%s.tif' % pattern)))
        if not hits:
            missing.append('%s (%dnm)' % (pattern.replace('*', ' '), wavelength))
            continue
        if len(hits) > 1:
            ambiguous.append('%s -> %s' % (pattern.replace('*', ' '),
                                           ', '.join(os.path.basename(h) for h in hits[:3])))
        matched.append((band_no, wavelength, hits[0]))

    if missing:
        raise ProcessError(
            "'%s'에 필요한 밴드 영상을 찾지 못했습니다: %s" % (sensor, ', '.join(missing)),
            "Pix4D 기본 파일명(blue, green, red, red edge, nir 등)이 유지되어야 합니다."
            " 파일명을 변경했다면 원래대로 되돌리거나 센서 선택을 확인하세요.")

    for a in ambiguous:
        log.warn("밴드 파일이 여러 개 검색되어 첫 번째를 사용합니다: %s" % a)

    return matched


# ------------------------------------------------------------------ 처리
def _copy_bands(outputpath, matched, project_name):
    """밴드파일(tif 및 동반 prj/tfw)을 B## 명명 규칙으로 복사."""
    copied = []
    for band_no, wavelength, src in matched:
        base = os.path.splitext(src)[0]
        for ext in ('tif', 'tfw', 'prj'):
            s = base + '.' + ext
            if not os.path.exists(s):
                continue
            d = os.path.join(outputpath, '%s_B%02d_%dnm.%s'
                             % (project_name, band_no, wavelength, ext))
            try:
                shutil.copy2(s, d)
            except Exception as e:
                raise ProcessError(
                    "밴드 파일 복사에 실패했습니다: %s" % os.path.basename(s),
                    _write_fail_hint(d, e))
            if ext == 'tif':
                copied.append(d)
    return copied


def _build_vrt(vrt_path, tifs, infos, labels=None):
    """밴드중첩 VRT 생성.

    밴드별 격자가 다르면 상태만 알리고 재표본화 없이 그대로 중첩한다.
    격자 정합은 Pix4D Mapper 처리 단계에서 해결해야 할 사항이므로
    이 플러그인에서 영상을 임의로 변형하지 않는다.
    """
    aligned, problems, advisories = check_grid_consistency(infos, labels)
    for a in advisories:
        log.warn(a)

    if not aligned:
        log.warn("밴드별 격자가 일치하지 않습니다. 밴드중첩 결과가 어긋날 수 있습니다.")
        for p in problems:
            log.detail("· " + p)
        log.hint("Pix4D Mapper에서 동일한 출력 해상도·범위로 재처리한 뒤 다시 실행하세요.")

    vrt = gdal.BuildVRT(vrt_path, tifs, separate=True)
    if vrt is None:
        raise ProcessError("밴드중첩(VRT) 생성에 실패했습니다.",
                           "밴드 영상의 좌표계와 범위가 올바른지 확인하세요.")
    vrt.FlushCache()
    vrt = None
    wait_for_rasters([vrt_path], settle=0)


def _vrt_to_int16_tif(vrt_path, tif_path, matched):
    """VRT를 scale factor 적용 int16 GeoTIFF로 변환하고 밴드별 통계 출력."""
    ds = gdal.Open(vrt_path)
    driver = gdal.GetDriverByName("GTiff")
    try:
        out = driver.Create(
            tif_path, ds.RasterXSize, ds.RasterYSize, ds.RasterCount, gdal.GDT_Int16,
            options=["COMPRESS=LZW", "PREDICTOR=2", "BIGTIFF=IF_SAFER"])
    except Exception as e:
        raise ProcessError("밴드중첩 영상을 만들 수 없습니다: %s" % os.path.basename(tif_path),
                           _write_fail_hint(tif_path, e))
    if out is None:
        raise ProcessError("밴드중첩 영상을 만들 수 없습니다: %s" % os.path.basename(tif_path),
                           _write_fail_hint(tif_path, None))

    out.SetGeoTransform(ds.GetGeoTransform())
    out.SetProjection(ds.GetProjection())

    empty_bands = []
    common_valid = None          # 전 밴드가 동시에 유효한 화소
    int16_max = np.iinfo(np.int16).max
    for i in range(1, ds.RasterCount + 1):
        raw = ds.GetRasterBand(i).ReadAsArray().astype(np.float32)
        a = raw * SCALE_FACTOR
        a[np.isnan(a)] = NODATA
        a[a == 0] = NODATA
        a[a <= NODATA] = NODATA

        # int16 상한(32767 = 반사도 3.2767) 초과분은 포화 처리 (오버플로 방지)
        over = a > int16_max
        n_over = int(over.sum())
        if n_over:
            a[over] = int16_max
            log.warn("B%02d: 반사도가 3.2767을 넘는 화소 %d개(%.2f%%)를 상한값으로 저장했습니다."
                     % (i, n_over, n_over / float(a.size) * 100))
        arr = a.astype(np.int16)

        band = out.GetRasterBand(i)
        band.WriteArray(arr)
        band.SetNoDataValue(NODATA)
        band.SetScale(1.0 / SCALE_FACTOR)
        band.SetOffset(0.0)

        valid = arr > NODATA
        common_valid = valid if common_valid is None else (common_valid & valid)

        wavelength = matched[i - 1][1] if i - 1 < len(matched) else 0
        st = band_statistics(arr, scale=1.0 / SCALE_FACTOR)
        if st['valid_ratio'] == 0:
            empty_bands.append('B%02d' % i)
            log.detail("B%02d (%4dnm): 유효 화소 없음" % (i, wavelength))
        else:
            log.detail("B%02d (%4dnm): 유효화소 %5.1f%%, 반사도 %.3f~%.3f (평균 %.3f)"
                       % (i, wavelength, st['valid_ratio'] * 100,
                          st['min'], st['max'], st['mean']))
            if st['max'] > 2.0:
                log.warn("B%02d 반사도가 2.0을 넘습니다. 입력이 반사도가 아닌 DN 영상일 수 있습니다." % i)

    ds = None
    out = None

    if empty_bands:
        raise ProcessError(
            "밴드중첩 결과에 유효한 화소가 없습니다: %s" % ', '.join(empty_bands),
            "밴드별 촬영 범위가 서로 겹치지 않거나 입력 영상이 비어 있는지 확인하세요.")

    # 전 밴드가 함께 유효한 영역 점검 (밴드별 범위가 어긋나면 사용할 수 없는 산출물)
    if common_valid is not None:
        ratio = float(common_valid.mean())
        if ratio == 0:
            raise ProcessError(
                "모든 밴드가 함께 유효한 화소가 없습니다.",
                "밴드별 촬영 범위가 서로 겹치지 않습니다. 서로 다른 지역의 자료가 섞여 있는지 "
                "확인하고, Pix4D Mapper에서 동일한 범위로 재처리하세요.")
        if ratio < 0.5:
            log.warn("전 밴드가 함께 유효한 영역이 %.1f%%에 불과합니다. "
                     "밴드별 촬영 범위가 어긋났을 수 있습니다." % (ratio * 100))
        else:
            log.info("전 밴드 공통 유효 영역: %.1f%%" % (ratio * 100))


# ------------------------------------------------------------------ 진입점
def _composite_multispectral(path, sensor, cfg):
    inputpath, input_tifs = validate_project_folder(path, cfg, sensor)
    outputpath = os.path.join(path, '1_initial/report')

    log.section("1/3 단계 · 입력 자료 확인")
    log.info("센서: %s (%s), 밴드 %d개" % (sensor, cfg['code'], len(cfg['bands'])))
    log.info("입력 경로: %s" % inputpath)
    log.info("산출 경로: %s" % outputpath)

    _check_file_count(input_tifs, cfg, sensor)
    matched = _match_bands(inputpath, cfg['bands'], sensor)

    infos = [raster_info(src) for _, _, src in matched]
    ref = infos[0]
    log.info("영상 크기: %d x %d 화소, 해상도 %.4f m, 좌표계 %s"
             % (ref['width'], ref['height'], ref['pixel_size'], ref['crs'] or '정보 없음'))
    if not ref['crs']:
        log.warn("좌표계 정보가 없습니다. 산출물이 QGIS에서 올바른 위치에 표시되지 않을 수 있습니다.")

    total_mb = sum(i['size_bytes'] for i in infos)
    log.info("입력 자료 용량: %s" % human_size(total_mb))
    free = free_space(path)
    if free is not None and free < total_mb * 2:
        log.warn("디스크 여유 공간이 부족할 수 있습니다 (남은 용량 %s)." % human_size(free))

    log.section("2/3 단계 · 밴드중첩")
    clean_report_folder(outputpath)

    project_name = _project_name(matched[0][2], path)
    log.info("프로젝트명: %s" % project_name)

    log.step("밴드 파일 정리 (%d개)" % len(matched))
    copied = _copy_bands(outputpath, matched, project_name)
    wait_for_rasters(copied)

    vrt_path = os.path.join(outputpath, project_name + '.vrt')
    tif_path = os.path.join(outputpath, project_name + '.tif')

    log.step("밴드중첩 구성 및 격자 검사")
    labels = ['B%02d(%dnm)' % (no, wl) for no, wl, _ in matched]
    with GdalErrorCollector():
        _build_vrt(vrt_path, copied, infos, labels)

        log.step("반사도 변환 및 저장 (int16, x%d)" % SCALE_FACTOR)
        _vrt_to_int16_tif(vrt_path, tif_path, matched)

    # 중간산출물 정리
    for pattern in ('*.vrt', '*nm.prj', '*nm.tfw', '*nm.tif'):
        for f in glob.glob(os.path.join(outputpath, pattern)):
            try:
                os.remove(f)
            except OSError:
                pass

    wait_for_rasters([tif_path], settle=0)
    log.lap("밴드중첩 완료: %s (%s)"
            % (os.path.basename(tif_path), human_size(os.path.getsize(tif_path))))
    return tif_path


def _composite_rgb(path, sensor, cfg):
    inputpath, input_tifs = validate_project_folder(path, cfg, sensor)
    outputpath = os.path.join(path, '1_initial/report')

    log.section("1/3 단계 · 입력 자료 확인")
    log.info("센서: %s (%s)" % (sensor, cfg['code']))
    log.info("입력 경로: %s" % inputpath)
    log.info("산출 경로: %s" % outputpath)

    if len(input_tifs) > 1:
        log.warn("정사모자이크 파일이 %d개 있어 첫 번째를 사용합니다: %s"
                 % (len(input_tifs), os.path.basename(input_tifs[0])))

    src_path = input_tifs[0]
    info = raster_info(src_path)
    log.info("입력 영상: %s (%s)" % (info['name'], human_size(info['size_bytes'])))
    log.info("영상 크기: %d x %d 화소, %d밴드, 해상도 %.4f m, 좌표계 %s"
             % (info['width'], info['height'], info['count'],
                info['pixel_size'], info['crs'] or '정보 없음'))

    if info['count'] < 3:
        raise ProcessError(
            "RGB 영상은 3밴드 이상이어야 하나 %d밴드입니다." % info['count'],
            "선택한 파일이 정사모자이크(RGB)가 아닌 DSM 등 단일밴드 산출물일 수 있습니다."
            " 다중분광 자료라면 센서 선택을 변경하세요.")
    if info['count'] == 3:
        log.info("Alpha 밴드가 없어 RGB 3밴드를 그대로 저장합니다.")
    elif info['count'] > 4:
        log.warn("밴드가 %d개입니다. 앞의 3개를 RGB로, 4번째를 Alpha로 처리합니다." % info['count'])

    log.section("2/3 단계 · RGB 저장 (Alpha 밴드 제외)")
    clean_report_folder(outputpath)

    project_name = _project_name(src_path, path)
    log.info("프로젝트명: %s" % project_name)
    tif_path = os.path.join(outputpath, project_name + '.tif')

    with GdalErrorCollector():
        ds = gdal.Open(src_path)
        driver = gdal.GetDriverByName("GTiff")
        try:
            out = driver.Create(
                tif_path, ds.RasterXSize, ds.RasterYSize, 3, gdal.GDT_Byte,
                options=["COMPRESS=LZW", "BIGTIFF=IF_SAFER", "PHOTOMETRIC=RGB", "TILED=YES"])
        except Exception as e:
            raise ProcessError("RGB 영상을 만들 수 없습니다: %s" % os.path.basename(tif_path),
                               _write_fail_hint(tif_path, e))
        if out is None:
            raise ProcessError("RGB 영상을 만들 수 없습니다: %s" % os.path.basename(tif_path),
                               _write_fail_hint(tif_path, None))

        out.SetGeoTransform(ds.GetGeoTransform())
        out.SetProjection(ds.GetProjection())

        alpha = ds.GetRasterBand(4).ReadAsArray() if ds.RasterCount >= 4 else None
        if alpha is not None:
            ratio = float((alpha > 0).mean())
            log.detail("Alpha 밴드 제거 (유효 영역 %.1f%%)" % (ratio * 100))
            if ratio < 0.01:
                raise ProcessError(
                    "정사모자이크의 유효 영역이 거의 없습니다 (%.2f%%)." % (ratio * 100),
                    "Pix4D 처리 결과가 정상인지 확인하세요.")

        names = ('Red', 'Green', 'Blue')
        interp = (gdal.GCI_RedBand, gdal.GCI_GreenBand, gdal.GCI_BlueBand)
        for i in range(1, 4):
            a = ds.GetRasterBand(i).ReadAsArray()
            if alpha is not None:
                a = np.where(alpha == 0, 0, a).astype(np.uint8)
            band = out.GetRasterBand(i)
            band.WriteArray(a)
            band.SetNoDataValue(0)
            band.SetColorInterpretation(interp[i - 1])
            valid = a[a > 0]
            if valid.size:
                log.detail("%-5s: 유효화소 %5.1f%%, DN %d~%d (평균 %.0f)"
                           % (names[i - 1], valid.size / float(a.size) * 100,
                              int(valid.min()), int(valid.max()), valid.mean()))
        ds = None
        out = None

    wait_for_rasters([tif_path], settle=0)
    log.lap("RGB 저장 완료: %s (%s)"
            % (os.path.basename(tif_path), human_size(os.path.getsize(tif_path))))
    return tif_path


def band_composite(path, sensor):
    cfg = SENSORS.get(sensor)
    if cfg is None:
        raise ProcessError("알 수 없는 센서입니다: %s" % sensor,
                           "지원 센서: %s" % ', '.join(SENSORS.keys()))
    if cfg.get('type') == 'rgb':
        return _composite_rgb(path, sensor, cfg)
    return _composite_multispectral(path, sensor, cfg)
