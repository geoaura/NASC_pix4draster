# -*- coding: utf-8 -*-
# 식생지수(NDVI, GNDVI, NDRE) 계산
# 밴드 인덱스를 센서 설정(sensors.py)에서 파장 기준으로 자동 결정

import os
import glob
import numpy as np

from .sensors import SENSORS, VI_WAVELENGTHS, SCALE_FACTOR, NODATA
from .logger import log, ProcessError, human_size
from .io import (geotiff_input, geotiff_output, GdalErrorCollector, _write_fail_hint,
                 wait_for_rasters)


def _normalized_difference(a, b, valid):
    """(a-b)/(a+b) 계산. 무효 화소/0나눗셈은 nodata(-2) 처리 후 반환(float32, [-1,1])."""
    with np.errstate(divide='ignore', invalid='ignore'):
        vi = (a - b) / (a + b)
    vi = vi.astype(np.float32)
    np.clip(vi, -1.0, 1.0, out=vi)
    vi[~np.isfinite(vi)] = -2.0
    vi[vi == 0] = -2.0          # 기존 동작 유지: 0 -> nodata
    vi[~valid] = -2.0           # 입력 밴드 nodata 화소 -> nodata
    return vi


def _find_composite(path):
    """report 폴더에서 밴드중첩 산출물 탐색 (식생지수 산출물 제외)."""
    if not os.path.isdir(path):
        raise ProcessError(
            "산출물 폴더가 없습니다: %s" % path,
            "먼저 [Composite bands]로 밴드중첩을 수행한 뒤 식생지수를 계산하세요.")

    cands = [f for f in sorted(glob.glob(os.path.join(path, '*.tif')))
             if '_index_' not in os.path.basename(f)]
    if not cands:
        raise ProcessError(
            "밴드중첩 영상을 찾을 수 없습니다: %s" % path,
            "[Composite bands]를 함께 선택해 밴드중첩을 먼저 수행하세요.")
    if len(cands) > 1:
        log.warn("밴드중첩 영상이 %d개 있어 첫 번째를 사용합니다: %s"
                 % (len(cands), os.path.basename(cands[0])))
    return cands[0]


def cal_vi(path, sensor):
    cfg = SENSORS.get(sensor)
    if cfg is None:
        raise ProcessError("알 수 없는 센서입니다: %s" % sensor,
                           "지원 센서: %s" % ', '.join(SENSORS.keys()))

    if not cfg.get('vi', True):
        log.section("3/3 단계 · 식생지수")
        log.info("'%s'는 근적외선(NIR) 밴드가 없어 식생지수를 계산하지 않습니다." % sensor)
        return []

    log.section("3/3 단계 · 식생지수 계산")

    src = _find_composite(path)
    log.info("입력 영상: %s" % os.path.basename(src))

    # 기존 식생지수 산출물 제거
    old = glob.glob(os.path.join(path, '*_index_*.tif'))
    for f in old:
        try:
            os.remove(f)
        except PermissionError:
            raise ProcessError(
                "기존 식생지수 파일을 삭제할 수 없습니다: %s" % os.path.basename(f),
                "QGIS 레이어 목록에서 해당 파일을 제거한 뒤 다시 실행하세요.")
    if old:
        log.info("기존 식생지수 %d개를 삭제하고 새로 생성합니다." % len(old))

    wait_for_rasters([src], settle=0)
    with GdalErrorCollector():
        band, xcor, ycor, zcor, geotransform, projection = geotiff_input(src)

    # 밴드 수 검증
    expected = len(cfg['bands'])
    if zcor != expected:
        raise ProcessError(
            "밴드중첩 영상의 밴드 수(%d)가 '%s' 기준(%d)과 다릅니다." % (zcor, sensor, expected),
            "밴드중첩 시 선택한 센서와 지금 선택한 센서가 같은지 확인하세요."
            " 다르다면 밴드중첩부터 다시 실행하세요.")

    # 파장 -> 밴드 인덱스
    wavelengths = [wl for _, wl in cfg['bands']]
    missing = [wl for wl in VI_WAVELENGTHS if wl not in wavelengths]
    if missing:
        raise ProcessError(
            "'%s'에는 식생지수 계산에 필요한 밴드가 없습니다: %s nm"
            % (sensor, ', '.join(str(m) for m in missing)),
            "Green(560), Red(668), Red-edge(717), NIR(842) 밴드가 모두 필요합니다.")
    idx = {wl: wavelengths.index(wl) for wl in VI_WAVELENGTHS}

    r560 = band[:, :, idx[560]].astype(np.float32)
    r668 = band[:, :, idx[668]].astype(np.float32)
    r717 = band[:, :, idx[717]].astype(np.float32)
    r842 = band[:, :, idx[842]].astype(np.float32)
    del band

    valid = (r560 > NODATA) & (r668 > NODATA) & (r717 > NODATA) & (r842 > NODATA)
    valid_ratio = float(valid.mean())
    log.info("영상 크기: %d x %d 화소, 유효 화소 %.1f%%" % (xcor, ycor, valid_ratio * 100))
    if valid_ratio == 0:
        raise ProcessError(
            "식생지수를 계산할 유효 화소가 없습니다.",
            "밴드중첩 영상이 정상인지 확인하세요. 밴드별 촬영 범위가 겹치지 않으면 발생합니다.")
    if valid_ratio < 0.1:
        log.warn("유효 화소 비율이 매우 낮습니다 (%.1f%%). 밴드 정합 상태를 확인하세요." % (valid_ratio * 100))

    indices = {
        'NDVI':  _normalized_difference(r842, r668, valid),
        'GNDVI': _normalized_difference(r842, r560, valid),
        'NDRE':  _normalized_difference(r842, r717, valid),
    }
    del r560, r668, r717, r842

    stem = os.path.basename(src)[:-4]
    outputs = []
    with GdalErrorCollector():
        for name, vi in indices.items():
            vi_int16 = (vi * SCALE_FACTOR).astype(np.int16)   # -2 -> -20000 (nodata)
            outputpath = os.path.join(path, '%s_index_%s.tif' % (stem, name))
            geotiff_output(outputpath, xcor, ycor, geotransform, projection, vi_int16,
                           scale=1.0 / SCALE_FACTOR)
            outputs.append(outputpath)

            v = vi[valid]
            # 평균은 0~1 구간(식생 영역)만 대상으로 산출
            # 음수 구간(수체·그림자·비식생)이 평균을 끌어내리는 것을 방지
            in_range = v[(v >= 0.0) & (v <= 1.0)]
            share = in_range.size / float(v.size) if v.size else 0.0

            if in_range.size:
                log.detail("%-5s: %.3f ~ %.3f (0~1 평균 %.3f, 해당 %.1f%%)  ->  %s"
                           % (name, float(v.min()), float(v.max()),
                              float(in_range.mean()), share * 100,
                              os.path.basename(outputpath)))
            else:
                log.detail("%-5s: %.3f ~ %.3f (0~1 구간 없음)  ->  %s"
                           % (name, float(v.min()), float(v.max()),
                              os.path.basename(outputpath)))

            if name == 'NDVI' and share < 0.1:
                log.warn("NDVI가 0~1 구간에 드는 화소가 %.1f%%에 불과합니다. "
                         "밴드 순서나 입력 자료를 확인하세요." % (share * 100))

    log.lap("식생지수 %d종 생성 완료" % len(outputs))
    return outputs
