# -*- coding: utf-8 -*-
import os
import glob
import time
import shutil
import numpy as np
from osgeo import gdal, osr

from .sensors import NODATA
from .logger import log, ProcessError, human_size

gdal.UseExceptions()

# 새로 만든 파일을 GDAL이 즉시 인식하지 못하는 문제(디렉터리 목록 캐시) 방지
gdal.SetConfigOption('GDAL_DISABLE_READDIR_ON_OPEN', 'EMPTY_DIR')

# ---- 파일 생성 후 인식 대기 설정 -------------------------------------------
# 복사·저장 직후 곧바로 열면 백신 검사, 네트워크 드라이브 지연 등으로
# 파일이 아직 보이지 않을 수 있어 잠시 기다렸다가 사용한다.
FILE_SETTLE_DELAY = 1.0     # 복사 직후 기본 대기 시간 (초)
FILE_WAIT_TIMEOUT = 15.0    # 최대 대기 시간 (초)
FILE_WAIT_INTERVAL = 0.3    # 재확인 간격 (초)


# ---------------------------------------------------------------- GDAL 오류 수집
class GdalErrorCollector(object):
    """GDAL 내부 경고/오류를 로그로 전달하는 핸들러."""

    def __init__(self):
        self.messages = []

    def handler(self, err_class, err_no, err_msg):
        msg = err_msg.strip()
        if not msg:
            return
        self.messages.append(msg)
        if err_class >= gdal.CE_Failure:
            log.error("GDAL: %s" % msg)
        elif err_class == gdal.CE_Warning:
            log.warn("GDAL: %s" % msg)

    def __enter__(self):
        gdal.PushErrorHandler(self.handler)
        return self

    def __exit__(self, *args):
        gdal.PopErrorHandler()
        return False


# ---------------------------------------------------------------- 파일 인식 대기
def _is_readable(path):
    """파일이 존재하고 GDAL로 열 수 있는지 확인 (오류 메시지는 표시하지 않음)."""
    try:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return False
    except OSError:
        return False

    gdal.PushErrorHandler('CPLQuietErrorHandler')
    try:
        ds = gdal.Open(path)
        ok = ds is not None
        ds = None
    except Exception:
        ok = False
    finally:
        gdal.PopErrorHandler()
    return ok


def wait_for_rasters(paths, settle=FILE_SETTLE_DELAY, timeout=FILE_WAIT_TIMEOUT):
    """새로 만든 래스터가 열릴 수 있을 때까지 대기.

    복사·저장 직후 곧바로 열면 파일이 실제로는 존재하는데도
    '파일 없음'으로 실패하는 경우가 있어(백신 검사, 네트워크 드라이브,
    디스크 쓰기 지연), 기본 대기 후 열릴 때까지 재확인한다.
    """
    if not paths:
        return

    if settle > 0:
        time.sleep(settle)

    deadline = time.time() + timeout
    pending = [p for p in paths if not _is_readable(p)]
    waited = False
    while pending and time.time() < deadline:
        waited = True
        time.sleep(FILE_WAIT_INTERVAL)
        pending = [p for p in pending if not _is_readable(p)]

    if waited and not pending:
        log.detail("파일 인식까지 잠시 대기했습니다.")

    if pending:
        exists = [p for p in pending if os.path.exists(p)]
        names = ', '.join(os.path.basename(p) for p in pending[:3])
        if exists:
            raise ProcessError(
                "파일이 만들어졌으나 %.0f초 내에 열리지 않았습니다: %s" % (timeout, names),
                "백신 프로그램의 실시간 검사에서 산출물 폴더를 제외하거나, "
                "네트워크 드라이브·클라우드 동기화 폴더(OneDrive 등)가 아닌 "
                "로컬 디스크에서 실행해 보세요.")
        raise ProcessError(
            "생성한 파일을 찾을 수 없습니다: %s" % names,
            "산출물 폴더의 쓰기 권한과 디스크 여유 공간을 확인하세요.")


def raster_info(filepath):
    """래스터 기본 정보 조회. 열 수 없으면 ProcessError."""
    try:
        ds = gdal.Open(filepath)
    except Exception as e:
        raise ProcessError(
            "영상 파일을 열 수 없습니다: %s" % os.path.basename(filepath),
            "파일이 손상되었거나 GeoTIFF 형식이 아닌지 확인하세요. (%s)" % e)
    if ds is None:
        raise ProcessError(
            "영상 파일을 열 수 없습니다: %s" % os.path.basename(filepath),
            "파일이 손상되었거나 다른 프로그램이 사용 중일 수 있습니다.")

    gt = ds.GetGeoTransform()
    proj = ds.GetProjection()
    info = {
        'path': filepath,
        'name': os.path.basename(filepath),
        'width': ds.RasterXSize,
        'height': ds.RasterYSize,
        'count': ds.RasterCount,
        'geotransform': gt,
        'projection': proj,
        'pixel_size': abs(gt[1]) if gt else 0.0,
        'origin': (gt[0], gt[3]) if gt else (0, 0),
        'dtype': gdal.GetDataTypeName(ds.GetRasterBand(1).DataType),
        'size_bytes': os.path.getsize(filepath),
    }
    srs_name = ''
    if proj:
        try:
            srs = osr.SpatialReference(wkt=proj)
            srs_name = srs.GetAttrValue('AUTHORITY', 0) or ''
            code = srs.GetAttrValue('AUTHORITY', 1) or ''
            if srs_name and code:
                srs_name = '%s:%s' % (srs_name, code)
            else:
                srs_name = srs.GetAttrValue('PROJCS') or srs.GetAttrValue('GEOGCS') or ''
        except Exception:
            srs_name = ''
    info['crs'] = srs_name
    ds = None
    return info


def check_grid_consistency(infos, labels=None):
    """밴드 영상들의 격자(크기·해상도·원점·좌표계) 일치 여부 검사.

    labels: 밴드 표시명 목록 (예: ['B01 560nm', ...]). 없으면 파일명 사용.
    반환: (일치 여부, 불일치 항목 리스트, 참고 경고 리스트)

    격자가 다르면 밴드중첩 시 화소가 어긋난다. 이 함수는 진단만 수행하며
    영상을 변형하지 않는다 (격자 정합은 Pix4D Mapper 처리 단계의 몫).
    """
    problems, advisories = [], []
    if labels is None or len(labels) != len(infos):
        labels = [i['name'][:28] for i in infos]

    sizes = {(i['width'], i['height']) for i in infos}
    if len(sizes) > 1:
        detail = ', '.join('%s=%dx%d' % (l, i['width'], i['height'])
                           for l, i in zip(labels, infos))
        problems.append("영상 크기 불일치 (%s)" % detail)

    pixels = {round(i['pixel_size'], 8) for i in infos}
    if len(pixels) > 1:
        detail = ', '.join('%s=%.6g m' % (l, i['pixel_size'])
                           for l, i in zip(labels, infos))
        problems.append("해상도(화소 크기) 불일치 (%s)" % detail)

    origins = {(round(i['origin'][0], 4), round(i['origin'][1], 4)) for i in infos}
    if len(origins) > 1:
        detail = ', '.join('%s=(%.2f, %.2f)' % (l, i['origin'][0], i['origin'][1])
                           for l, i in zip(labels, infos))
        problems.append("좌상단 원점 좌표 불일치 (%s)" % detail)

    crss = {i['crs'] for i in infos if i['crs']}
    if len(crss) > 1:
        problems.append("좌표계 불일치 (%s)" % ', '.join(sorted(crss)))

    missing_crs = [l for l, i in zip(labels, infos) if not i['projection']]
    if missing_crs:
        if len(missing_crs) == len(infos):
            advisories.append("모든 밴드에 좌표계 정보가 없습니다.")
        else:
            advisories.append("좌표계 정보가 없는 밴드: %s" % ', '.join(missing_crs))

    return (len(problems) == 0), problems, advisories


def band_statistics(array, nodata=NODATA, scale=1.0):
    """유효 화소 비율과 값 범위 요약."""
    total = array.size
    valid_mask = array > nodata
    valid = int(valid_mask.sum())
    if valid == 0:
        return {'valid_ratio': 0.0, 'min': None, 'max': None, 'mean': None}
    vals = array[valid_mask].astype(np.float64) * scale
    return {
        'valid_ratio': valid / float(total),
        'min': float(vals.min()),
        'max': float(vals.max()),
        'mean': float(vals.mean()),
    }


# ---------------------------------------------------------------- 입출력
def geotiff_input(inputpath):
    """단일 GeoTIFF를 읽어 (Band(H,W,Z), xcor, ycor, zcor, GeoTransform, Projection) 반환."""
    files = glob.glob(inputpath)
    if not files:
        raise ProcessError("영상을 찾을 수 없습니다: %s" % inputpath)

    ds = gdal.Open(files[0])
    if ds is None:
        raise ProcessError("영상을 열 수 없습니다: %s" % os.path.basename(files[0]))
    ycor, xcor, zcor = ds.RasterYSize, ds.RasterXSize, ds.RasterCount
    geotransform = ds.GetGeoTransform()
    projection = ds.GetProjection()
    band = np.dstack([ds.GetRasterBand(k).ReadAsArray() for k in range(1, zcor + 1)])
    ds = None
    return band, xcor, ycor, zcor, geotransform, projection


def geotiff_output(outputpath, xcor, ycor, geotransform, projection, var,
                   dtype=gdal.GDT_Int16, nodata=NODATA, scale=None):
    """단일 밴드 GeoTIFF 저장 (기본: Int16, LZW 압축, nodata=-20000).

    scale: DN -> 물리값 변환계수 (예: 0.0001). 지정 시 밴드 메타데이터에 기록되어
           QGIS 등에서 자동으로 물리값(-1~1 식생지수 등)으로 표시됨.
    """
    driver = gdal.GetDriverByName("GTiff")
    try:
        out = driver.Create(outputpath, xcor, ycor, 1, dtype,
                            options=['COMPRESS=LZW', 'PREDICTOR=2', 'BIGTIFF=IF_SAFER'])
    except Exception as e:
        raise ProcessError(
            "산출물을 만들 수 없습니다: %s" % os.path.basename(outputpath),
            _write_fail_hint(outputpath, e))
    if out is None:
        raise ProcessError(
            "산출물을 만들 수 없습니다: %s" % os.path.basename(outputpath),
            _write_fail_hint(outputpath, None))

    out.SetGeoTransform(geotransform)
    out.SetProjection(projection)
    band = out.GetRasterBand(1)
    band.WriteArray(var)
    band.SetNoDataValue(nodata)
    if scale is not None:
        band.SetScale(scale)
        band.SetOffset(0.0)
    out.FlushCache()
    out = None


def _write_fail_hint(path, err):
    folder = os.path.dirname(path)
    if not os.access(folder, os.W_OK):
        return "폴더에 쓰기 권한이 없습니다. 다른 위치에 프로젝트를 복사한 뒤 실행하세요."
    free = free_space(folder)
    if free is not None and free < 200 * 1024 * 1024:
        return "디스크 여유 공간이 부족합니다 (남은 용량 %s)." % human_size(free)
    return ("같은 이름의 파일이 QGIS나 다른 프로그램에서 열려 있는지 확인하고 닫은 뒤 다시 실행하세요."
            + (" (%s)" % err if err else ""))


def free_space(folder):
    try:
        return shutil.disk_usage(folder).free
    except Exception:
        return None


# ---------------------------------------------------------------- 폴더 정리
def clean_report_folder(outpath):
    """report 폴더 내 기존 산출물(tif/tfw/prj/vrt) 삭제 후 폴더 보장.

    QGIS에 해당 파일이 올라가 있으면 Windows에서 삭제가 막히므로
    원인을 구체적으로 안내한다.
    """
    try:
        os.makedirs(outpath, exist_ok=True)
    except Exception as e:
        raise ProcessError(
            "산출물 폴더를 만들 수 없습니다: %s" % outpath,
            "경로가 올바른지, 쓰기 권한이 있는지 확인하세요. (%s)" % e)

    if not os.access(outpath, os.W_OK):
        raise ProcessError(
            "산출물 폴더에 쓰기 권한이 없습니다: %s" % outpath,
            "관리자 권한이 필요한 위치(C:\\Program Files 등)나 읽기 전용 드라이브가 아닌지 확인하세요.")

    removed, locked = 0, []
    for ext in ('*.tif', '*.tfw', '*.prj', '*.vrt', '*.tif.aux.xml', '*.tif.ovr'):
        for f in glob.glob(os.path.join(outpath, ext)):
            try:
                os.remove(f)
                removed += 1
            except PermissionError:
                locked.append(os.path.basename(f))
            except OSError as e:
                locked.append("%s (%s)" % (os.path.basename(f), e))

    if locked:
        raise ProcessError(
            "기존 산출물을 삭제할 수 없습니다: %s" % ', '.join(locked[:5]),
            "해당 파일이 QGIS 레이어 목록에 올라가 있으면 삭제되지 않습니다. "
            "QGIS에서 레이어를 제거하거나 다른 프로그램을 닫은 뒤 다시 실행하세요.")

    if removed:
        log.info("기존 산출물 %d개 삭제 후 재생성합니다." % removed)
    else:
        log.info("report 폴더가 비어 있어 새로 생성합니다.")
