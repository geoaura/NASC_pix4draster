# -*- coding: utf-8 -*-
# QGIS Plugin entry (GUI에서 호출되는 API)

import os
import traceback

from .module.logger import log, ProcessError, human_size
from .module.band_composite import band_composite
from .module.vegetation_index import cal_vi


def _report_error(e):
    """ProcessError는 원인·조치를 정리해 출력, 그 외는 예외 정보를 남긴다."""
    if isinstance(e, ProcessError):
        log.error(e.message)
        if e.hint:
            log.hint(e.hint)
    elif isinstance(e, MemoryError):
        log.error("메모리가 부족하여 처리를 완료하지 못했습니다.")
        log.hint("다른 프로그램을 종료하거나, 영상 범위를 나누어 처리하세요.")
    else:
        log.error("예기치 못한 오류가 발생했습니다: %s" % e)
        log.hint("아래 상세 정보를 담당자에게 전달해 주세요.")
        for line in traceback.format_exc().strip().splitlines()[-4:]:
            log.detail(line)
    return False


def composite_process_directory(directory, sensor):
    """밴드중첩 수행. 성공 시 산출물 경로, 실패 시 None."""
    try:
        return band_composite(directory, sensor)
    except Exception as e:
        _report_error(e)
        return None


def vi_process_directory(directory, sensor):
    """식생지수 계산. 성공 시 산출물 목록, 실패 시 None."""
    try:
        return cal_vi(directory, sensor)
    except Exception as e:
        _report_error(e)
        return None


def summarize(outputpath):
    """산출물 목록 요약 출력."""
    log.section("처리 결과 요약")
    if not os.path.isdir(outputpath):
        log.warn("산출물 폴더가 없습니다: %s" % outputpath)
        return
    files = sorted(f for f in os.listdir(outputpath) if f.lower().endswith('.tif'))
    if not files:
        log.warn("생성된 산출물이 없습니다.")
        return
    for f in files:
        size = os.path.getsize(os.path.join(outputpath, f))
        log.info("%-45s %s" % (f, human_size(size)))
    log.info("저장 위치: %s" % outputpath)
